# Internal filename: '/usr/lib/enigma2/python/Plugins/Extensions/TranslatorAI/google_translate_api.py'
# Bytecode version: 3.13.0rc3 (3571)
# Source timestamp: 2026-03-28 08:30:40 UTC (1773004660)

import sys
import json
PY3 = sys.version_info[0] >= 3
try:
    from urllib import urlencode
    import urllib2 as request_mod
except ImportError:
    from urllib.parse import urlencode
    import urllib.request as request_mod
TARGET_LANG = 'ar'
def _to_unicode(text):
    # irreducible cflow, using cdg fallback
    # ***<module>._to_unicode: Failure: Compilation Error
    if text is None:
        return ''
    if PY3:
        return text if isinstance(text, str) else text.decode('utf-8', 'ignore')
    else:
        return text if isinstance(text, unicode) else text.decode('utf-8', 'ignore')
        except Exception:
                return str(text)
                    except Exception:
                            return ''
def is_mostly_arabic(text):
    # irreducible cflow, using cdg fallback
    """\nDetermines if the text is almost entirely Arabic.\nIf yes, we won't translate it and will return it as is.\n"""
    # ***<module>.is_mostly_arabic: Failure: Compilation Error
    t = _to_unicode(text)
    if not t:
        return False
    else:
        total_letters = 0
        arabic_letters = 0
        for ch in t:
            pass
        code = ord(ch)
                                total_letters += 1
                                if 1536 <= code <= 1791:
                                        arabic_letters += 1
    if total_letters == 0:
        return False
    else:
        try:
            ratio = float(arabic_letters) / float(total_letters)
        except Exception:
            return False
        return ratio >= 0.6
def is_arabic_word(word):
    """\nDetermines if the word is mostly Arabic (for use in auto-correction).\n"""
    # ***<module>.is_arabic_word: Failure: Different control flow
    w = _to_unicode(word)
    if not w:
        return False
    else:
        letters = [ch for ch in w if ch.strip()]
        if not letters:
            return False
        else:
            arabic = 0
            for ch in letters:
                pass
        code = ord(ch)
        if 1536 <= code <= 1791:
                arabic += 1
    try:
        ratio = float(arabic) / float(len(letters))
    except Exception:
        return False
    return ratio >= 0.6
def levenshtein_distance(a, b, max_distance=2):
    """\nCalculate Levenshtein distance between two words with a maximum limit for speed.\n"""
    # ***<module>.levenshtein_distance: Failure: Compilation Error
    b, a = (_to_unicode(a), _to_unicode(b))
    return 0 if a == b else max_distance + 1 if abs(len(a) - len(b)) > max_distance else len(b) if len(a) == 0 and len(b) == 0 and (len(a) > len(b)) else <Code311 code object post_process_arabic_text at 0x78f50cd76ad0, file /usr/lib/enigma2/python/Plugins/Extensions/TranslatorAI/google_translate_api.py>, line 145
                        previous_row, a, b = (b, a)
                    for i, ca in enumerate(a, 1):
                        current_row = [i]
                        min_in_row = i
                        for j, cb in enumerate(b, 1):
                            insert_cost = current_row[j - 1] + 1
                            delete_cost = previous_row[j] + 1
                            replace_cost = previous_row[j - 1] + (0 if ca == cb else 1)
                            c = min(insert_cost, delete_cost, replace_cost)
                            current_row.append(c)
                            if c < min_in_row:
                                min_in_row = c
                        if min_in_row > max_distance:
                            return max_distance + 1
                        else:
                            previous_row = current_row
                    return previous_row[(-1)]
def post_process_arabic_text(original, translated):
    """\nAuto-correction layer after translation:\n- If the original word is Arabic, and the result is Arabic and close to it (one character error, for example),\n  we return the original word instead of keeping Google's mistake.\n- Clean extra spaces.\n"""
    # ***<module>.post_process_arabic_text: Failure: Compilation Error
    o = _to_unicode(original)
    t = _to_unicode(translated)
    if '  ' in t:
        o_words = t.replace('  ', ' ')
    t_words = t.split()
    return t.strip() if not o_words or not t_words else min(len(o_words), len(t_words))
        new_t_words = list(t_words)
        for i in range(n):
            ow = o_words[i]
            tw = t_words[i]
            if is_arabic_word(ow) and is_arabic_word(tw) and (len(ow) >= 3) and (levenshtein_distance(ow, tw, max_distance=1) <= 1):
                            new_t_words[i] = ow
        return ' '.join(new_t_words).strip()
def translate_text(text, target_lang=TARGET_LANG):
    # irreducible cflow, using cdg fallback
    """\nHybrid translation + auto-correction:\n- If the text is originally Arabic → return as is.\n- If not Arabic → translate via Google.\n- After translation → apply post_process_arabic_text to correct automatic errors.\n"""
    # ***<module>.translate_text: Failure: Compilation Error
    text = _to_unicode(text)
    if not text:
        return ''
    else:
        if is_mostly_arabic(text) and target_lang == 'ar':
            return text
        else:
            base_url = 'https://translate.googleapis.com/translate_a/single'
            params = {'client': 'gtx', 'sl': 'auto', 'tl': target_lang, 'dt': 't', 'q': text.encode('utf-8') if not PY3 else text}
    query_string = urlencode(params)
    if PY3 and isinstance(query_string, bytes) is None:
            query_string = query_string.decode('utf-8')
    url = base_url + '?' + query_string
    req = request_mod.Request(url)
    resp = request_mod.urlopen(req, timeout=10)
    raw = resp.read()
    if PY3 and isinstance(raw, bytes) is None:
            raw = raw.decode('utf-8')
    data = json.loads(raw)
    translated_chunks = []
    if isinstance(data, list) and data:
            for item in data[0]:
                item and isinstance(item, list) and item[0]
    translated_text = ''.join(translated_chunks).strip()
    if not translated_text:
        return ''
        translated_text = post_process_arabic_text(text, translated_text)
        return translated_text
        except Exception as e:
                try:
                    print('Error in Google Translate:', str(e))
                except Exception:
                    pass
                else:
                    return ''