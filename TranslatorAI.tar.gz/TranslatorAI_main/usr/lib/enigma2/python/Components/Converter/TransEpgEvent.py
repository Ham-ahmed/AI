```python
# -*- coding: utf-8 -*-
# Developed by Hamdy Ahmed  26/03/2026.

from Components.Converter.Converter import Converter
from Components.Element import cached
from enigma import eEPGCache

# Use TransEpg settings + controller if available
try:
    from Components.config import config
    from Plugins.Extensions.TransEpg.plugin import TransEpgController
except Exception:
    config = None
    TransEpgController = None


class TransEpgEvent(Converter, object):
    NAME = 0
    DESCRIPTION = 1
    FULL = 2  # FullDescription

    def __init__(self, type):
        Converter.__init__(self, type)
        t = (type or "").strip()
        if t == "Name":
            self.type = self.NAME
        elif t == "Description":
            self.type = self.DESCRIPTION
        else:
            self.type = self.FULL

    @cached
    def getText(self):
        event = getattr(self.source, "event", None)

        if event is None:
            service = getattr(self.source, "service", None)
            if service is not None:
                try:
                    epgcache = eEPGCache.getInstance()
                    event = epgcache.lookupEventTime(service, -1)
                except Exception:
                    event = None

        if event is None:
            return ""

        name = event.getEventName() or ""
        short = event.getShortDescription() or ""
        ext = event.getExtendedDescription() or ""

        if not (name or short or ext):
            return ""

        desc_parts = [p for p in (short, ext) if p]
        desc_text = "\n".join(desc_parts).strip()

        # Controller
        ctrl = None
        try:
            if TransEpgController is not None:
                ctrl = TransEpgController.instance
        except Exception:
            ctrl = None

        # Helper function to get from cache only
        def _get_cached(text):
            if not text or ctrl is None or not getattr(ctrl, "enabled", False):
                return None
            try:
                lang = config.plugins.TransEpg.language.value
            except Exception:
                lang = "ar"
            cache_key = "%s|%s" % (lang, text)
            return ctrl.cache.get(cache_key, None)

        # Try to get translation from cache
        name_t = _get_cached(name) if name else None
        desc_t = _get_cached(desc_text) if desc_text else None

        # If not in cache → trigger background translation
        if ctrl is not None and getattr(ctrl, "enabled", False):
            try:
                if name and name_t is None:
                    ctrl.translate_async(name)
                if desc_text and desc_t is None:
                    ctrl.translate_async(desc_text)
            except Exception as e:
                print("[TransEpgEvent] translate_async error:", e)

        # What to display now:
        # First time: usually no translation → show original
        # After cache is filled: same converter or next time will find translation and display it
        if name_t is None:
            name_t = name
        if desc_t is None:
            desc_t = desc_text

        if self.type == self.NAME:
            return name_t or name

        if self.type == self.DESCRIPTION:
            return desc_t or name_t or name

        # FULL: name + description
        parts = []
        if name_t:
            parts.append(name_t)
        if desc_t:
            parts.append(desc_t)
        full = "\n".join(parts)
        if not full:
            full = name or desc_text
        return full

    text = property(getText)

    def changed(self, what):
        Converter.changed(self, what)
```